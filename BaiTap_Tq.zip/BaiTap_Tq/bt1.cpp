#include<stdio.h>
int main(){
	char a;
	int b;
	float c,d,e;
	printf("Nhap ten mat hang: ");
    scanf("%c",&a);
    fflush(stdin);
	printf("Nhap trong luong: ");
	scanf("%f",&e);
	printf("Nhap don gia:");
	scanf("%f",&c);
	printf("Nhap ma chat luong:");
	scanf("%f",&d);
	printf("Nhap so luong:");
	scanf("%d",&b);
	return 0;	
}
